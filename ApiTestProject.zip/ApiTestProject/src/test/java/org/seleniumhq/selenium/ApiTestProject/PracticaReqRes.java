package org.seleniumhq.selenium.ApiTestProject;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.junit.*;
import static org.junit.Assert.assertEquals;


public class PracticaReqRes {
	
	@BeforeClass
	public static void classSetup() {
		
		try {
			RestAssured.baseURI = "https://reqres.in";
			RestAssured.basePath = "/api";
			
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}


	@Test 
	//Show all users from page #2
    public void getTest(){
		Response resp = RestAssured.given().log().all().param("page", 2)
	            .get("/users")
	            .then()
	            .extract().response();
		resp.body().prettyPrint();
		assertEquals(200, resp.statusCode());
	        }

	
	@Test
	//Add a new user
    public void postTest(){
		Response resp = RestAssured.given()
            .accept("content-type")
            . body("{\"name\":\"ivonne\", \"job\":\"sdet\"}")
            .post("/users")
            .then()
            .extract().response();
	resp.body().prettyPrint();
	assertEquals(201, resp.statusCode());
    }
	
	
	@Test
	//Update an especific user
	public void putTest(){
	     
	    // Se crea el dato de prueba
		JsonPath jsonPath  = RestAssured.given()
		        .accept(ContentType.JSON)
		        . body("{\"name\":\"flor\", \"job\":\"tester\"}")
		        .post("/users")
		    .then()
		        .extract().jsonPath();
		    ;
	     
	    // Se extrae el dato de la llamada
		String idCreated =  jsonPath.get("id").toString() ;
	                     
		Response resp = RestAssured.given()
		    .log().all()
		        .accept(ContentType.JSON)
		        .contentType(ContentType.JSON)
		        . body("{ \"job\" : \"leader\" }")
		        .put("/users/"+idCreated)       //se utiliza el dato creado en el POST
		        .then()
				.extract().response();
		resp.body().prettyPrint();
		assertEquals(200, resp.statusCode());
		}
	
	
	@Test
	//Delete an user
	public void delete(){
	     
	    //se crea el recurso
	    JsonPath jsonPath  = RestAssured.given().log().all()
	            .accept(ContentType.JSON)
	            . body("{\"name\":\"flor\", \"job\":\"tester\"}")
	            .post("/users")
	        .then()
	        .extract().jsonPath();
	        ;
	         
	      String idCreated = ( jsonPath.get("id").toString() );
	     
	    //se elimina el recurso
	        RestAssured.given().log().all()
	        .accept(ContentType.JSON)
	        .param("id", idCreated)
	        .delete("/users")
	    .then().log().ifValidationFails()
	    .statusCode(204);          
	}
}
