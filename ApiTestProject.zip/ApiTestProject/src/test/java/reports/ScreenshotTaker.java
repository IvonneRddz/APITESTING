package reports;

import org.apache.cassandra.io.util.FileUtils;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class ScreenshotTaker extends TestWatcher {
    private static WebDriver browser;
    private String screenshotLocation;
    private String title ="test1";
    private String filenameOfReport= "C:/myReportingDir/testReport" + title + ".html";
     
    public ScreenshotTaker(WebDriver browser, String screenshotLocation) {
    	this.browser=browser;
    	this.screenshotLocation=screenshotLocation;
    }
    
    
    
   	public static String takeScreenshotAtEndOfTest(WebDriver browser, String screenshotLocation) throws IOException {
    	    String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
    	    TakesScreenshot ts = (TakesScreenshot) browser;
    	    File source = ts.getScreenshotAs(OutputType.FILE);
    	    String destination = System.getProperty("user.dir") + "/screenshots/" +  dateName
    	            + ".png";
    	    File finalDestination = new File(destination);
    	    FileHandler.copy(source, finalDestination);
    	    return destination;
    }
 
    @Override
    protected void failed(Throwable e, Description description) {
        TakesScreenshot takesScreenshot = (TakesScreenshot) browser;
        File scrFile = takesScreenshot.getScreenshotAs(OutputType.FILE);
        File destFile = getDestinationFile(description);
        ExtentReports extent = createReport();
        ExtentTest test = extent.startTest(description.getDisplayName(), "Test failed, click here for further details");
 
        // step log
        test.log(LogStatus.FAIL, "Failure trace Selenium: "+ e.toString());
        flushReports(extent, test);
    }
     
    //When passed only write to the log.
    @Override
    protected void succeeded(Description description) {
        ExtentReports extent = createReport();
         ExtentTest test = extent.startTest(description.getDisplayName(), "-");
 
        // step log
        test.log(LogStatus.PASS, "-");
        flushReports(extent, test);
    }
 
    private ExtentReports createReport() {
        ExtentReports extent = new ExtentReports(filenameOfReport, false);
        extent.config().reportName("My first extentReport report");
        extent.config().reportHeadline("See my awesome passed tests!");
        return extent;
    }
     
    private void flushReports(ExtentReports extent, ExtentTest test){
        // ending test
        extent.endTest(test);
        // writing everything to document
        extent.flush();
    }
     
    private File getDestinationFile(Description description) {
        String userDirectory = screenshotLocation;
        String date = getDateTime();
        String fileName = description.getDisplayName() + "_" + date + ".png";
        //add date of today
        //String dateForDir = DateTimeHelper.getDateOfToday();
        String absoluteFileName = userDirectory + "/" + title + "/" + fileName;
 
        return new File(absoluteFileName);
    }
     
    private String getDateTime() {
        Date date = Calendar.getInstance().getTime();
 
        // Display a date in day, month, year format
        DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy_HH_mm_ss");
        String today = formatter.format(date);
        return today;
    }
}