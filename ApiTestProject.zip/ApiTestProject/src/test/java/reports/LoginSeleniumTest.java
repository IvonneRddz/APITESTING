package reports;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.seleniumhq.selenium.ApiTestProject.EReport;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import org.hamcrest.CoreMatchers;

public class LoginSeleniumTest{
	
	private static WebDriver driver;
	
		@Rule
		public EReport name = new EReport(System.getProperty("user.dir") + "\\target\\SeleniumReport.html");

		@BeforeClass
		public static void classSetup() {
			try {
				//System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
				 //driver = new ChromeDriver();
				//System.setProperty("webdriver.gecko.driver","C:\\Users\\ivonn\\Downloads\\geckodriver.exe");
				//WebDriver driver = new FirefoxDriver();
				//driver.manage().window().maximize();
				 //	driver.navigate().to("http://the-internet.herokuapp.com/login");
				
			} catch (Exception ex) {
				System.out.println(ex.getMessage());
			}
		}

		@Test
		public void login() {
			System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
			 driver = new ChromeDriver();
			 
			driver.get("http://the-internet.herokuapp.com/login");
			System.out.println("its here");
			
			WebElement userName = driver.findElement(By.name("username"));
			userName.sendKeys("tomsmith");

			WebElement password = driver.findElement(By.id("password"));
			password.sendKeys("SuperSecretPassword!");

			WebElement login = driver.findElement(By.xpath("//button[@class='radius']"));
			login.click();
			
			WebElement mns = driver.findElement(By.xpath("//div[@id='flash']"));
			assertThat(mns.getText(), CoreMatchers.containsString("You logged into a secure area"));
			
	}

		@AfterClass
		public static void tearDown() {
			System.out.println("---Tests finished---");
			driver.quit();
		}
	}
	