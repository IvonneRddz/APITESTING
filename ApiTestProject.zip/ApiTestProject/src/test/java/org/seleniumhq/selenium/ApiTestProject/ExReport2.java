package org.seleniumhq.selenium.ApiTestProject;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static org.junit.Assert.assertEquals;
//import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;


//Ejemplo de REQRES.IN Usando @ROLE

public class ExReport2 {

	//static ExtentTest test;
	//static ExtentReports report;

	String testName= "Test 1";
	
	@Rule
	public EReport name = new EReport(System.getProperty("user.dir") + ("\\") +testName+(".html"));
	
	@BeforeClass
	public static void classSetup() {
		try {
			RestAssured.baseURI = "https://reqres.in";
			RestAssured.basePath = "/api";

		//	report = new ExtentReports(System.getProperty("user.dir") + "\\ExtentReportResults.html");
		//	test = report.startTest("ExtentDemo");

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	@Test
	//Get all users on the page 2
	public void getUsers() {
		//String stepName = "Show all users";
		Response resp = RestAssured.given()
				.header("content-type", "application/json")
				.when()
				.param("page", 2)
				.get("/users");
		resp.body().prettyPrint();
		
			assertEquals(resp.getBody().jsonPath().get("page").toString(), "2");
	}

	@Test
	// Add a new user
	public void postTest() {
		Response resp = RestAssured.given()
				.accept("content-type")
				.body("{\"name\":\"ivonne\", \"job\":\"sdet\"}")
				.post("/users")
				.then()
				.extract()
				.response();
		resp.body().prettyPrint();

			assertEquals(201, resp.statusCode());
			}

	@Test
	// Update an user
	public void putTest() {

		JsonPath jsonPath = RestAssured.given()
				.accept(ContentType.JSON)
				.body("{\"name\":\"flor\", \"job\":\"tester\"}")
				.post("/users")
				.then()
				.extract()
				.jsonPath();
		;


		String idCreated = jsonPath.get("id").toString();

		Response resp = RestAssured.given()
				.log()
				.all()
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON)
				.body("{ \"job\" : \"leader\" }")
				.put("/users/" + idCreated) // se utiliza el dato creado en el POST
				.then()
				.extract()
				.response();
		resp.body().prettyPrint();
			assertEquals(200, resp.statusCode());
	}

	@Test
	// Delete an user
	public void delete() {
		JsonPath jsonPath = RestAssured
				.given()
				.log()
				.all()
				.accept(ContentType.JSON)
				.body("{\"name\":\"flor\", \"job\":\"tester\"}")
				.post("/users")
				.then()
				.extract()
				.jsonPath();
		;

		String idCreated = (jsonPath.get("id").toString());
		Response resp = RestAssured.given()
				.header("Content-type", "application/json")
				.param("id", idCreated)
				.delete("/users/")
				.then().
				extract().
				response();
		resp.body().prettyPrint();
			assertEquals(204, resp.statusCode());
	}

}


	
//	@AfterClass
	//public static void endTest() {
		//report.endTest(test);
		//report.flush();
	//}
//}