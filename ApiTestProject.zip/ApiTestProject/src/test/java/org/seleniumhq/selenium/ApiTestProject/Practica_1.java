package org.seleniumhq.selenium.ApiTestProject;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.*;
import static org.junit.Assert.assertEquals;

public class Practica_1 {

	private static String newUser = "{\"name\":\"Ivonne\" ,\"job\":\"SDET\"}";
	private static String updateUser = "{\"name\":\"Ivonne\" ,\"job\":\"Dev\"}";

	@BeforeClass
	public static void classSetup() {
		try {
			RestAssured.baseURI = "https://reqres.in";
			RestAssured.basePath = "/api";
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	
	@Test
	public void postUser() {
		Response resp = RestAssured.given()
				.header("Content-type", "application/json")
				.body(newUser)
				.post("/users")
				.then()
				.extract().response();
		resp.body().prettyPrint();
		assertEquals(201, resp.statusCode());
		assertEquals(resp.getBody().jsonPath().get("name").toString(),"Ivonne");
	}	
	
	
	@Test
	public void getUsers() {
		Response resp = RestAssured.given()
				.header("content-type", "application/json")
				.when()
				.get("/users")
				.then()
				.extract().response();
		resp.body().prettyPrint();
		assertEquals(200,resp.statusCode());
	}
	
	
	@Test
	public void updatetUser() {
		Response resp = RestAssured.given()
				.header("Content-type", "application/json")
				.body(updateUser)
				.put("/users")
				.then()
				.extract().response();
		resp.body().prettyPrint();
		assertEquals(200, resp.statusCode());
		assertEquals(resp.getBody().jsonPath().get("job").toString(),"Dev");
	}	
	
	
	@Test
	public void deletetUser() {
		Response resp = RestAssured.given()
				.header("Content-type", "application/json")
				.param("id",5)
				.delete("/users/")
				.then()
				.extract().response();
		resp.body().prettyPrint();
		assertEquals(204, resp.statusCode());
	}	
}