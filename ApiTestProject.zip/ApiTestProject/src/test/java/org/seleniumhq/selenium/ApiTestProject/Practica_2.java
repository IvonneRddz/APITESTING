package org.seleniumhq.selenium.ApiTestProject;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.*;
import static org.junit.Assert.assertEquals;

import java.util.Random;


public class Practica_2 {

		@BeforeClass
		public static void classSetup() {
			try {
				RestAssured.baseURI = "https://pokeapi.co/";
				RestAssured.basePath = "api/v2/";
			} catch (Exception ex) {
				System.out.println(ex.getMessage());
			}
		}

		
		@Test
		public void randomPokemon() {

			Random numRan = new Random();
			Integer idRan = numRan.nextInt(60);
			
			Response resp = RestAssured.given()
					.header("content-type", "application/json")
					.when()
					.get("/pokemon/{id}", idRan);
			resp.body().prettyPrint();
			assertEquals(200,resp.statusCode());
			assertEquals(resp.getBody().jsonPath().get("id").toString(),idRan.toString());
		}	
		
		
	}